package testcases.api;

import com.testframework.api.RestCommentController;
import com.testframework.api.RestPostController;
import com.testframework.api.RestUserController;
import com.testframework.api.models.Comment;
import com.testframework.api.models.Post;
import com.testframework.api.models.RequestUser;
import com.testframework.api.models.ResponseUser;
import com.testframework.factories.UserFactory;
import com.testframework.generations.GenerateRandom;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RestCommentControllerTests extends BaseApiTest {


    private RequestUser user;
    private Response createdUser;
    private Cookie authCookie;
    private Post post;
    private Post createdPost;
    private Comment comment;
    private Response createdComment;
    private int commentId;

    @BeforeEach
    public void setup() {
        user = new RequestUser("ROLE_USER", UserFactory.createUser());

        createdUser = RestUserController.createUser(user);
        String username = user.getUsername();
        String password = user.getPassword();

        Response auth = RestUserController.authUser(username, password)
                .baseUri("http://localhost:8081/authenticate")
                .when()
                .post();
        authCookie = auth.getDetailedCookie("JSESSIONID");
        post = new Post();
        createdPost = new RestPostController().createPost(post, authCookie.getValue());
        post.setPostId(createdPost.getPostId());
        ResponseBody userBody = createdUser.getBody();
        var myArray = userBody.asString().split(" ");
        var responseId = myArray[6];
        int userId = Integer.valueOf(responseId);

        comment = new Comment(userId, createdPost.getPostId());
        createdComment = RestCommentController.createComment(comment, authCookie.getValue());
        JsonPath jsonPathEvaluator = createdComment.jsonPath();
        commentId = jsonPathEvaluator.get("commentId");

    }
    @AfterEach
    public void cleanup() {
        //Delete user
    }

    @Test
    public void getAllCommentsByPost() {
        Comment[] comments = RestCommentController.getAllCommentsOnPost(post.getPostId(), authCookie.getValue());
        Assertions.assertTrue(comments.length > 0, "There are no comments on this post.");


    }

    @Test
    public void createComment() {
        String testValue = RestCommentController.getSingleComment(commentId).getContent();
        Assertions.assertEquals(comment.getContent(), testValue, "Comment content does not match.");
    }

    @Test
    public void getOneComment() {
        Comment singleComment = RestCommentController.getSingleComment(commentId);
        Assertions.assertEquals(singleComment.getContent(), comment.getContent(), "Comment does not match search.");

    }

    @Test
    public void editComment() {
        String content = GenerateRandom.generateRandomBoundedAlphanumericString(20);
        RestCommentController.editComment(commentId,content, authCookie.getValue());

    }

    @Test
    public void likeComment() {
        Response like = RestCommentController.likeComment(commentId, authCookie.getValue());
        int likeSize = like.jsonPath().getList("likes").size();
        Assertions.assertTrue(likeSize > 0, "There are no likes on this post.");
    }

    @Test
    public void deleteComment() {
        RestCommentController.deleteComment(commentId, authCookie.getValue());
    }

}
