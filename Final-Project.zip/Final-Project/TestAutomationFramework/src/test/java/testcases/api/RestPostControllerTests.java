package testcases.api;

import com.testframework.api.RestPostController;
import com.testframework.api.models.Post;
import com.testframework.api.models.PostEditor;
import com.testframework.factories.UserFactory;
import com.testframework.generations.GenerateRandom;
import dev.failsafe.internal.util.Assert;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.*;
import com.testframework.api.RestUserController;

import com.testframework.api.models.RequestUser;

import static io.restassured.RestAssured.given;

public class RestPostControllerTests extends BaseApiTest {
    private RequestUser user;
    private Cookie authCookie;
    private Post post;
    private Post createdPost;

    @BeforeEach
    public void setup() {
        user = new RequestUser("ROLE_USER", UserFactory.createUser());

        Response createdUser = RestUserController.createUser(user);
        String username = user.getUsername();
        String password = user.getPassword();

        Response auth = RestUserController.authUser(username, password)
                .baseUri("http://localhost:8081/authenticate")
                .when()
                .post();
        authCookie = auth.getDetailedCookie("JSESSIONID");
        post = new Post();
        createdPost = new RestPostController().createPost(post, authCookie.getValue());
        post.setPostId(createdPost.getPostId());

    }

    @AfterEach
    public void cleanup() {
       // UserControllerHelper.deleteUser("username", String.format("'%s'", user.getUsername()));
        RestPostController.deletePost(createdPost.getPostId(), authCookie.getValue());
    }

    @Test
    public void findAllPublicPosts() {
        Post[] posts = RestPostController.getAllPosts();
        Assertions.assertTrue(posts.length > 0, "There are no posts.");


    }

    @Test
    public void createPost() {
        Assertions.assertEquals(post, createdPost, "The json body doesn't match the created post.");
    }

    @Test
    public void editPost() {

        PostEditor editor = new PostEditor();
        String newContent = editor.getContent();

        Response editPost = RestPostController.editPost(createdPost.getPostId(),editor, authCookie.getValue());
      //  String testContent =  post.getContent();
        //Assertions.assertEquals(newContent, testContent, "The json body doesn't match the edited post.");

    }

    @Test
    public void likePost() {
        Response like = RestPostController.likePost(createdPost.getPostId(), authCookie.getValue());
        int likeSize = like.jsonPath().getList("likes").size();
        Assertions.assertTrue(likeSize > 0, "There are no likes on this post.");
    }

    @Test
    public void deletePost() {
        Response delete = RestPostController.deletePost(createdPost.getPostId(), authCookie.getValue());

    }

}
