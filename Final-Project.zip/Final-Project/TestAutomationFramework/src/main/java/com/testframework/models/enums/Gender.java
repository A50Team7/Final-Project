package com.testframework.models.enums;

public enum Gender {
    MALE,
    FEMALE;
}
