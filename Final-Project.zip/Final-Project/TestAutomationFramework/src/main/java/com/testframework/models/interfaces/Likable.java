package com.testframework.models.interfaces;

public interface Likable {
    public void like();
    public void dislike();
}
