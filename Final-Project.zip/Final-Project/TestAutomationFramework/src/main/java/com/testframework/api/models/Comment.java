package com.testframework.api.models;

import com.testframework.generations.GenerateRandom;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Comment {
    private int userId;
    private int postId;
    private String content;

    public Comment(int userId, int postId) {
        setUserId(userId);
        setPostId(postId);
        setContent(GenerateRandom.generateRandomBoundedAlphabeticString(15));
    }


}
