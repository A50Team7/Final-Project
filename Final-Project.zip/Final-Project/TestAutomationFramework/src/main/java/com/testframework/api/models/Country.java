package com.testframework.api.models;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Country {

    private int id;

}
